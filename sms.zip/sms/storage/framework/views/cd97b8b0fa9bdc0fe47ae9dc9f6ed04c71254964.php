<?php $__env->startSection('body'); ?>
    <div class="row">
        <div class="col-lg-12">
            <div class="card">
                <div class="card-body">
                    <h4 class="card-title">Manage User</h4>
                    <div class="table-responsive">
                        <table class="table table-bordered table-hover mb-0">
                            <p class="text-center text-success"><?php echo e(Session::get('message')); ?></p>
                            <thead>
                            <tr>
                                <th>#</th>
                                <th>Name</th>
                                <th>Code</th>
                                <th>Email</th>
                                <th>Mobile</th>
                                <th>Address</th>
                                <th>Image</th>

                                <th>Action</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $teachers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $teacher): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <th scope="row"><?php echo e($loop->iteration); ?></th>
                                <td><?php echo e($teacher->name); ?></td>
                                <td><?php echo e($teacher->code); ?></td>
                                <td><?php echo e($teacher->email); ?></td>
                                <td><?php echo e($teacher->mobile); ?></td>
                                <td><?php echo e($teacher->address); ?></td>
                                <td><img src="<?php echo e($teacher->image); ?>" alt="" width="80" height="100"></td>
                                <td><?php echo e($teacher->status == 1 ? 'Active' : 'Inactive'); ?></td>
                                <td>
                                    <a href="<?php echo e(route('edit-teacher', ['id' =>$teacher->id])); ?>" class="btn btn-success btn-sm"><i class="fa fa-edit"></i></a>
                                    <a href="<?php echo e(route('delete-teacher', ['id' =>$teacher->id])); ?>" class="btn btn-danger btn-sm"><i class="fa fa-trash"></i></a>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>











<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sms\resources\views/admin/teacher/manage.blade.php ENDPATH**/ ?>